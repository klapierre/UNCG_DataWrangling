#Terminology
#Stage-tell git you want to add changes to repository history (add/delete files, edit files, etc.)
#Commit- confirm these changes with git; must make a commit message
#Pull- get any new changes on the GitHub repository; always PULL FIRST
#Push- send any committed (local) changes to the GitHub repository
#Halp