# MAP GROUP.    
##make sure to have a list of the errors you encounter while working on your code

#Section 1 (Carina) 
#ggmap, mapdata, maps, ggplot2, dplyr, stringr, maptools
#Libraries to be downloaded
#data set -> country, states and county
#Description of each library
#Description of how to render the US map
#let's try it

#Conclusion (Group)
#global distribution of something, heat map
#bigger problem where all skills listed above will be used




